void play1(int N);
int ask1(int* A);
void play2(int N);
int ask2(int* A);
void answer(int* A);
