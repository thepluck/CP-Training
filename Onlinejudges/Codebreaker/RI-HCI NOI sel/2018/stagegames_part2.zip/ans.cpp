#include "stagegames.h"
using namespace std;

void play1(int N) {

}

void play2(int N) {
	
}