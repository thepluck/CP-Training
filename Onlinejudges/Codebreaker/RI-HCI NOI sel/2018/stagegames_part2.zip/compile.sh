g++ grader.cpp ans.cpp -o stagegames -Wall -static -O2 -lm -m64 -s -w -std=gnu++14 -fmax-errors=512
