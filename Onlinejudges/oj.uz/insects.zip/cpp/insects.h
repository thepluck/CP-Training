void move_inside(int i);
void move_outside(int i);
int press_button();
int min_cardinality(int N);
