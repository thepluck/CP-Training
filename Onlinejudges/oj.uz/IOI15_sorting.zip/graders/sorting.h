#ifndef sorting_h
#define sorting_h

int findSwapPairs(int N, int S[], int M, int X[], int Y[], int P[], int Q[]);

#endif 

