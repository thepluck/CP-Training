public class sorting {
	public int findSwapPairs(int N, int S[], int M, int X[], int Y[], int P[], int Q[]) {
		P[0] = 0;
		Q[0] = 0;
		return 1;
	}
}

