#include "circuit.h"

#include <vector>

void init(int N, int M, std::vector<int> P, std::vector<int> A) {

}

int count_ways(int L, int R) {
  return 0;
}
