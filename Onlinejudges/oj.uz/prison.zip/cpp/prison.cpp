#include "prison.h"

#include <vector>

std::vector<std::vector<int>> devise_strategy(int N) {
  return {std::vector<int>(N + 1, 0)};
}
