#include <vector>

std::vector<std::vector<int>> devise_strategy(int N);
