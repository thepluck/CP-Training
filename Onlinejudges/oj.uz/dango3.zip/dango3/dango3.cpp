#include "dango3.h"

#include <vector>

namespace {

int variable_example = 1;

}  // namespace

void Solve(int N, int M) {
  std::vector<int> x(3);
  x[0] = 1;
  x[1] = 2;
  x[2] = 3;
  variable_example = Query(x);
  for (int i = 0; i < M; i++) {
    std::vector<int> a(N);
    for (int j = 0; j < N; j++) {
      a[j] = N * i + j + 1;
    }
    Answer(a);
  }
}
