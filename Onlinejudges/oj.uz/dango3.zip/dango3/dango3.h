#include <vector>

void Solve(int N, int M);

int Query(const std::vector<int> &x);
void Answer(const std::vector<int> &a);
