void Solve(int N);
int Query(int x);

void Answer(int x, int y);
