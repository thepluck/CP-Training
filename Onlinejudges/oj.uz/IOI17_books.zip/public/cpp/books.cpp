#include "books.h"

long long minimum_walk(std::vector<int> p, int s) {
	return 0;
}
