#include <vector>

long long minimum_walk(std::vector<int> p, int s);
