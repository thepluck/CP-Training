public class books {

	public long minimum_walk(int[] p, int s) {
		return 0;
	}
}
