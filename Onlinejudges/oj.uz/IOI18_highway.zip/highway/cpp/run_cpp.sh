#!/bin/bash

TASK=highway

./${TASK}
