#include <bits/stdc++.h>
#include "inversion.h"

const int N = 100000;

int a[N + 10];

void play(int n, long long initial_inversion) {
    doswap(1, 2);
    doswap(1, 2);
    for(int i = 1; i <= n; ++i) a[i] = i;
    answer(a);
}

