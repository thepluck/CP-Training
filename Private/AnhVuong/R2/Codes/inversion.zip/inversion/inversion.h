#ifndef INVERSION_H
#define INVERSION_H

long long doswap(int i, int j);
void answer(int p[]);
void play(int n, long long inv);

#endif

