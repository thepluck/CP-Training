void escape(int n);
bool jump(int x);
