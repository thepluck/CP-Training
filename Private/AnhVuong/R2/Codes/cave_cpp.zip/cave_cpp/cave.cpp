#include "cave.h"

const int MAXN = 5000 + 10;

int S[MAXN];
int D[MAXN];

void exploreCave(int N) {
    tryCombination(S);
    answer(S, D);
}
