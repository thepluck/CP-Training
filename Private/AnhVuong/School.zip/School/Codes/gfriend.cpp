#include <bits/stdc++.h>

using namespace std;

int main() {
    freopen("gfriend.inp", "r", stdin);
    freopen("gfriend.out", "w", stdout);
    cin.tie(0)->sync_with_stdio(0);
    int a, b; cin >> a >> b;
    cout << (a >= b);
}