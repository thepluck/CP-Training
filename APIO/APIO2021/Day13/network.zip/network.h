#ifndef __NETWORK_H__
#define __NETWORK_H__

#include <vector>
using namespace std;

vector<int> getMaximumSubset(int N, int D, int subtask, int x[], int y[]);

#endif
