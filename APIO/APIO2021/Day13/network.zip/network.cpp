#include "network.h"

vector<int> getMaximumSubset(int N, int D, int subtask, int x[], int y[]) {
  vector<int> res;
  return res;
}
