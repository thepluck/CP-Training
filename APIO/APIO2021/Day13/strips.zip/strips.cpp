#include "strips.h"

#include <vector>

int getMaximumLength(int N, std::vector<int> C) {
  return 0;
}
