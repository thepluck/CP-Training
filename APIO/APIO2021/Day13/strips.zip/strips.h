#ifndef __STRIPS_H__
#define __STRIPS_H__

#include <vector>

int getMaximumLength(int N, std::vector<int> C);

#endif
