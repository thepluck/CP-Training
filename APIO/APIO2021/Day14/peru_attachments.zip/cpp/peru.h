int solve(int n, int k, int* v);
