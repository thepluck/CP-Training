#include "peru.h"

int solve(int n, int k, int* v){
    return 0;
}
