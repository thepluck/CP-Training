#ifndef BRPERM_H
#define BRPERM_H

void init(int n, const char s[]);
int query(int i, int k);

#endif
