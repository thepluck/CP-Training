#!/bin/bash

g++ -DEVAL -O2 -std=c++11 grader.cpp floppy.cpp -o floppy
