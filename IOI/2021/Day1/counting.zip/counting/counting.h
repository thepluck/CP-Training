#ifndef __COUNTING_H__
#define __COUNTING_H__

int count_valid_board(int N, int K, int M);

#endif /* __COUNTING_H__ */
