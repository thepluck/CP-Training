#include <bits/stdc++.h>
#include "permutation.h"

void solve(int N) {
    vector<int> v;
    for(int i = 1; i <= N; ++i) {
        v.push_back(i);
    }

    query(v);
}
