#ifndef __PERMUTATION_H__
#define __PERMUTATION_H__

#include <vector>

void solve(int N);

int query(std::vector<int> v);

#endif /* __PERMUTATION_H__ */
