#include "tree.h"

double count_average_height(int N, std::vector<int> DFS, std::vector<int> BFS) {
  return -1;
}
