#ifndef __TREE_H__
#define __TREE_H__

#include <vector>

double count_average_height(int N, std::vector<int> DFS, std::vector<int> BFS);

#endif /* __TREE_H__ */
