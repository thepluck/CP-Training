#include "matching.h"

int count_matching(int N, int M, int A, int B, std::vector<int> U, std::vector<int> V) {
  return 0;
}
