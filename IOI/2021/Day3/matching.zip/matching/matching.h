#ifndef __MATCHING_H__
#define __MATCHING_H__

#include <vector>

int count_matching(int N, int M, int A, int B, std::vector<int> U, std::vector<int> V);

#endif /* __MATCHING_H__ */
