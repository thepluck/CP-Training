#include <string>
#include <vector>
#include "seat.h"

long long query(const std::vector<int> &B) {
  return 0;
}

void prepare(int N, std::vector<int> A, std::string C, int Q) {

}