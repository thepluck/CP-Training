#ifndef __GRASS_H__
#define __GRASS_H__

#include <vector>

std::vector<long long> simulate(int N, int H, int M, std::vector<char> events, std::vector<int> X);

#endif /* __GRASS_H__ */
