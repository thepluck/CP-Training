#include "grass.h"
#include <vector>

std::vector<long long> simulate(int N, int H, int M, std::vector<char> events, std::vector<int> X) {
    std::vector<long long> fertilizers;

    return fertilizers;
}
