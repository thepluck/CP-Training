#include "seedflare.h"
#include <bits/stdc++.h>
using namespace std;

vector<int> SortFlowers(int N) {
	vector<int> a;
	a.resize(N);
	for (int i = 1; i <= N; i++) a[i-1] = i;
	int res = SeedFlare(a);
	return a;
}
