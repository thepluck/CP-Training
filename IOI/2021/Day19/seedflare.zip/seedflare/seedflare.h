#include <vector>

std::vector<int> SortFlowers(int N);

int SeedFlare(std::vector<int> &v);