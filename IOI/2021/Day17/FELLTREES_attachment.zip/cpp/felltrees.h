#include <vector>

std::vector<int> fell_trees(int n, int q,
                            std::vector<int> x,
                            std::vector<int> h,
                            std::vector<int> l,
                            std::vector<int> r);