#include "permeow2.h"

int count_permutation(std::vector<int> p) {  
  return 0;
}
