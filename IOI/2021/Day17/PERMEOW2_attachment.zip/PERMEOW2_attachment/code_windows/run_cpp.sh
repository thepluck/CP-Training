#!/bin/bash

problem=permeow2

"./${problem}.exe"
