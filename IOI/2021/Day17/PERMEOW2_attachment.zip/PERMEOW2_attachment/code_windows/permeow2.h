#include <vector>

int count_permutation(std::vector<int> p);