#include <string>

void drill(std::string question, std::string answer);

std::string query(std::string question);
