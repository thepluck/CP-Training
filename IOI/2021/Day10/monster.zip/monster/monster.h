#include <vector>

std::vector<int> Solve(int N);
bool Query(int a, int b);
