#include "grader.h"
void Rescue(int R, int C, int RS, int CS, int X) {
  Measure(1, 2);
  Pinpoint(1, 2);
}
