int Measure(int RM, int CM);
void Pinpoint(int RP, int CP);
