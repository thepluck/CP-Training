#include <string>
using namespace std;

string encode(string rawMessage);
string decode(string encryptedMessage);
