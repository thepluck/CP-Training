#include <string>
using namespace std;

string encode(const string rawMessage) {
	return "00001111";
}

string decode(const string encryptedMessage) {
	return "31 23:59";
}
