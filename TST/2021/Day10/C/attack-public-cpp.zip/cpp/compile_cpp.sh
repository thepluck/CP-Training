#!/bin/bash

g++ -g -std=gnu++17 -O2 -Wall -pipe -static -o attack stub.cpp attack.cpp